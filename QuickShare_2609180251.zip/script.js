const messagesEl = document.getElementById('messages');
const input = document.getElementById('input');
const sendBtn = document.getElementById('send');
const clearBtn = document.getElementById('clear');
const providerBadge = document.getElementById('providerBadge');

let history = [];
let currentAssistantEl = null;
let currentAssistantRaw = '';

// Affiche le moteur actif (openai / ollama) récupéré depuis le serveur.
fetch('/api/config')
  .then((r) => r.json())
  .then((cfg) => {
    providerBadge.textContent = `${cfg.provider} · ${cfg.model}`;
  })
  .catch(() => {
    providerBadge.textContent = 'config indisponible';
  });

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Rendu markdown minimal : blocs de code ```lang ... ``` -> <pre><code>. */
function renderMarkdown(text) {
  const escaped = escapeHtml(text);
  return escaped.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, _lang, code) => {
    return `<pre><code>${code}</code></pre>`;
  });
}

function addMessage(role, text) {
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  const roleLabel = role === 'user' ? 'Toi' : 'Assistant';
  div.innerHTML = `<span class="role">${roleLabel}</span>${renderMarkdown(text)}`;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

function setAssistantContent(div, rawText) {
  div.innerHTML = `<span class="role">Assistant</span>${renderMarkdown(rawText)}`;
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function send() {
  const text = input.value.trim();
  if (!text) return;

  history.push({ role: 'user', content: text });
  addMessage('user', text);
  input.value = '';

  currentAssistantRaw = '';
  currentAssistantEl = addMessage('assistant', '');

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history }),
    });

    if (!res.ok || !res.body) {
      const errText = await res.text().catch(() => '');
      throw new Error(errText || `Erreur serveur ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const jsonStr = trimmed.slice(5).trim();
        if (!jsonStr) continue;

        let event;
        try {
          event = JSON.parse(jsonStr);
        } catch {
          continue;
        }

        if (event.type === 'chunk') {
          currentAssistantRaw += event.text;
          setAssistantContent(currentAssistantEl, currentAssistantRaw);
        } else if (event.type === 'error') {
          currentAssistantRaw += `\n\n[Erreur] ${event.message}`;
          setAssistantContent(currentAssistantEl, currentAssistantRaw);
        }
      }
    }

    history.push({ role: 'assistant', content: currentAssistantRaw });
  } catch (err) {
    setAssistantContent(currentAssistantEl, `[Erreur] ${err.message}`);
  } finally {
    currentAssistantEl = null;
  }
}

sendBtn.addEventListener('click', send);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});

clearBtn.addEventListener('click', () => {
  history = [];
  messagesEl.innerHTML = '';
});
