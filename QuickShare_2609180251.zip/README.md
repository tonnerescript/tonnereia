# Code Assistant Web

Une appli web autonome (façon Cursor/ChatGPT) que tu héberges toi-même, avec un backend
Node.js qui appelle **OpenAI** ou **Ollama** (modèle local) selon ta config.
Aucune dépendance à Claude/Anthropic, aucun besoin de repasser par un assistant pour la lancer :
une fois installée, elle tourne seule sur ton serveur.

## Architecture

```
code-assistant-web/
├── server.js           # backend Express : sert le front + proxifie les appels IA en streaming
├── package.json
├── .env.example         # à copier en .env
└── public/
    ├── index.html        # page du chat
    ├── style.css
    └── script.js         # logique du chat (streaming, rendu markdown minimal)
```

La clé API (si tu utilises OpenAI) reste **côté serveur**, dans `.env` — jamais exposée au navigateur.

## Lancer en local

Prérequis : Node.js 18+.

```bash
cd code-assistant-web
npm install
cp .env.example .env
```

Édite `.env` :

### Option A — OpenAI (cloud)
```
PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

### Option B — Ollama (local, gratuit, privé)
```
PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3
```
Avant de démarrer, dans un autre terminal :
```bash
ollama pull llama3
ollama serve
```

Puis lance le serveur :

```bash
npm start
```

Ouvre **http://localhost:3000** dans ton navigateur. C'est tout — le serveur tourne indépendamment,
tu peux fermer cette conversation, redémarrer ton PC, etc. : tant que `npm start` (ou le service
équivalent) tourne, l'appli est disponible.

## Héberger sur un vrai serveur / domaine

N'importe quel hébergeur qui fait tourner Node.js convient. Quelques options simples :

### Un VPS (Ubuntu, etc.)
```bash
git clone <ton-repo>   # ou envoie les fichiers par scp/rsync
cd code-assistant-web
npm install --production
cp .env.example .env   # puis édite-le
npm install -g pm2
pm2 start server.js --name code-assistant
pm2 save
```
`pm2` garde le serveur actif en arrière-plan et le relance s'il plante ou si la machine redémarre
(après `pm2 startup`). Mets ensuite Nginx ou Caddy devant pour le domaine + HTTPS.

### Plateformes "one-click" (Render, Railway, Fly.io, etc.)
- Connecte ton dépôt Git.
- Commande de build : `npm install`
- Commande de démarrage : `npm start`
- Ajoute les variables d'environnement du `.env.example` dans leur interface (jamais commitées).

### Docker (optionnel, si tu préfères des conteneurs)
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## Sécurité si tu exposes ça publiquement

- Ne commite jamais `.env` (déjà exclu via `.gitignore`).
- Si le site est public, ajoute au minimum une authentification simple (mot de passe, ou un proxy
  Nginx avec `auth_basic`) pour éviter que n'importe qui consomme ton quota OpenAI.
- Pense à un rate-limiting basique (ex: `express-rate-limit`) si le trafic est imprévisible.

## Pistes d'amélioration

- Authentification utilisateur (comptes, sessions).
- Historique de conversation persistant (base de données).
- Upload de fichiers/dossiers de code comme contexte.
- Support d'autres fournisseurs compatibles OpenAI (Mistral, Groq, LM Studio...).
