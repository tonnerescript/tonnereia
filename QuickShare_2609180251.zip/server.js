require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const CONFIG = {
  port: process.env.PORT || 3000,
  provider: process.env.PROVIDER || 'openai', // 'openai' | 'ollama'
  maxTokens: parseInt(process.env.MAX_TOKENS || '4096', 10),
  openai: {
    apiKey: process.env.OPENAI_API_KEY || '',
    model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    baseUrl: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
  },
  ollama: {
    baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
    model: process.env.OLLAMA_MODEL || 'llama3',
  },
};

const SYSTEM_PROMPT =
  "Tu es un assistant de programmation façon Cursor, intégré à un site web. Réponds en français, de façon concise et actionnable, avec des blocs de code quand c'est pertinent.";

/**
 * Renvoie la config active au frontend (jamais la clé API).
 */
app.get('/api/config', (_req, res) => {
  res.json({
    provider: CONFIG.provider,
    model: CONFIG.provider === 'openai' ? CONFIG.openai.model : CONFIG.ollama.model,
  });
});

/**
 * Endpoint de chat en streaming (Server-Sent Events).
 * Body attendu: { messages: [{ role: 'user'|'assistant', content: string }] }
 */
app.post('/api/chat', async (req, res) => {
  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages manquant ou vide' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const sendEvent = (data) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    if (CONFIG.provider === 'ollama') {
      await streamOllama(messages, sendEvent);
    } else {
      await streamOpenAI(messages, sendEvent);
    }
    sendEvent({ type: 'end' });
  } catch (err) {
    sendEvent({ type: 'error', message: err.message || String(err) });
  } finally {
    res.end();
  }
});

async function streamOpenAI(messages, sendEvent) {
  if (!CONFIG.openai.apiKey) {
    throw new Error(
      "Aucune clé API OpenAI configurée côté serveur (variable OPENAI_API_KEY dans .env)."
    );
  }

  const body = {
    model: CONFIG.openai.model,
    max_tokens: CONFIG.maxTokens,
    stream: true,
    messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
  };

  const response = await fetch(`${CONFIG.openai.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${CONFIG.openai.apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok || !response.body) {
    const text = await response.text().catch(() => '');
    throw new Error(`OpenAI a répondu ${response.status}: ${text}`);
  }

  await consumeSSE(response.body, (data) => {
    if (data === '[DONE]') return;
    try {
      const parsed = JSON.parse(data);
      const delta = parsed.choices?.[0]?.delta?.content;
      if (delta) sendEvent({ type: 'chunk', text: delta });
    } catch {
      // ligne partielle, ignorable
    }
  });
}

async function streamOllama(messages, sendEvent) {
  const body = {
    model: CONFIG.ollama.model,
    stream: true,
    messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
  };

  const response = await fetch(`${CONFIG.ollama.baseUrl}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!response.ok || !response.body) {
    const text = await response.text().catch(() => '');
    throw new Error(
      `Ollama a répondu ${response.status}: ${
        text || `vérifie que "ollama serve" tourne et que le modèle "${CONFIG.ollama.model}" est installé (ollama pull ${CONFIG.ollama.model})`
      }`
    );
  }

  await consumeNDJSON(response.body, (obj) => {
    const content = obj?.message?.content;
    if (content) sendEvent({ type: 'chunk', text: content });
  });
}

/** Parse un flux SSE (lignes "data: {...}"). */
async function consumeSSE(body, onEvent) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const data = trimmed.slice(5).trim();
      if (data) onEvent(data);
    }
  }
}

/** Parse un flux NDJSON (un objet JSON par ligne, format Ollama). */
async function consumeNDJSON(body, onObject) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try {
        onObject(JSON.parse(trimmed));
      } catch {
        // ligne partielle, ignorable
      }
    }
  }
}

app.listen(CONFIG.port, () => {
  console.log(`Code Assistant Web lancé sur http://localhost:${CONFIG.port}`);
  console.log(`Moteur actif : ${CONFIG.provider}`);
});
